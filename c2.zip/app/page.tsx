"use client"

import  from "../resources/scripts/components/NavigationBarServer"

export default function SyntheticV0PageForDeployment() {
  return < />
}