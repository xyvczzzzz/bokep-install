import type { Server } from "@/api/server/getServer"
import {
  Drawer,
  DrawerContent,
  DrawerHeader,
  DrawerDescription,
  DrawerFooter,
  DrawerClose,
} from "@/components/ui/drawer"
import { Button } from "@/components/ui/button"
import { Link } from "react-router-dom"
import { bytesToString, ip, mbToBytes } from "@/lib/formatters"
import CopyOnClick from "@/components/elements/CopyOnClick"
import tw from "twin.macro"
import styled from "styled-components/macro"
import type { ServerStats } from "@/api/server/getServerResourceUsage"

const StatsGrid = styled.div`
    ${tw`grid grid-cols-2 gap-4 p-4`}
`

const StatItem = styled.div`
    background-color: var(--secondary);
    ${tw`p-4 rounded-lg`}
    
    & .label {
        ${tw`text-neutral-400 text-sm mb-1`}
    }
    
    & .value {
        ${tw`text-lg font-semibold text-neutral-100`}
    }
    
    & .limit {
        ${tw`text-neutral-500 text-xs mt-1`}
    }
`

const ServerImage = styled.div<{ $image?: string }>`
    width: 100%;
    height: 200px;
    background: ${({ $image }) => ($image ? `url(${$image})` : "linear-gradient(135deg, #667eea 0%, #764ba2 100%)")};
    background-size: cover;
    background-position: center;
    border-radius: 12px;
    margin-bottom: 16px;
    position: relative;
    
    &::after {
        content: '';
        position: absolute;
        inset: 0;
        background: linear-gradient(to bottom, transparent 0%, rgba(0,0,0,0.7) 100%);
        border-radius: 12px;
    }
`

const ServerName = styled.div`
    position: absolute;
    bottom: 16px;
    left: 16px;
    z-index: 1;
    ${tw`text-2xl font-bold text-white`}
`

interface Props {
  server: Server
  stats: ServerStats | null
  isOpen: boolean
  onClose: () => void
}

export default ({ server, stats, isOpen, onClose }: Props) => {
  const diskLimit = server.limits.disk !== 0 ? bytesToString(mbToBytes(server.limits.disk)) : "Unlimited"
  const memoryLimit = server.limits.memory !== 0 ? bytesToString(mbToBytes(server.limits.memory)) : "Unlimited"
  const cpuLimit = server.limits.cpu !== 0 ? server.limits.cpu + " %" : "Unlimited"

  return (
    <Drawer open={isOpen} onOpenChange={onClose} direction="bottom">
      <DrawerContent>
        <DrawerHeader>
          <ServerImage $image={server.customImage}>
            <ServerName>{server.name}</ServerName>
          </ServerImage>

          <DrawerDescription>
            <div css={tw`flex items-center gap-2 mb-4`}>
              <span css={tw`text-neutral-400`}>IP Address:</span>
              {server.allocations
                .filter((alloc) => alloc.isDefault)
                .map((allocation) => (
                  <CopyOnClick
                    key={allocation.ip + allocation.port.toString()}
                    text={`${allocation.alias || ip(allocation.ip)}:${allocation.port}`}
                  >
                    <span
                      css={tw`font-mono text-neutral-100 bg-neutral-800 px-3 py-1 rounded-md cursor-pointer hover:bg-neutral-700`}
                    >
                      {allocation.alias || ip(allocation.ip)}:{allocation.port}
                    </span>
                  </CopyOnClick>
                ))}
            </div>
          </DrawerDescription>
        </DrawerHeader>

        {stats && (
          <StatsGrid>
            <StatItem>
              <div className="label">CPU Usage</div>
              <div className="value">{stats.cpuUsagePercent.toFixed(2)}%</div>
              <div className="limit">Limit: {cpuLimit}</div>
            </StatItem>

            <StatItem>
              <div className="label">Memory</div>
              <div className="value">{bytesToString(stats.memoryUsageInBytes)}</div>
              <div className="limit">Limit: {memoryLimit}</div>
            </StatItem>

            <StatItem>
              <div className="label">Disk Usage</div>
              <div className="value">{bytesToString(stats.diskUsageInBytes)}</div>
              <div className="limit">Limit: {diskLimit}</div>
            </StatItem>

            <StatItem>
              <div className="label">Status</div>
              <div className="value" css={tw`capitalize`}>
                {stats.status === "running" ? (
                  <span css={tw`text-green-400`}>Online</span>
                ) : stats.status === "offline" ? (
                  <span css={tw`text-red-400`}>Offline</span>
                ) : (
                  <span css={tw`text-yellow-400`}>Starting</span>
                )}
              </div>
            </StatItem>
          </StatsGrid>
        )}

        <DrawerFooter>
          <Link to={`/server/${server.id}`} css={tw`w-full`}>
            <Button css={tw`w-full`} size="lg">
              Manage Server
            </Button>
          </Link>
          <DrawerClose asChild>
            <Button variant="outline" css={tw`w-full`}>
              Close
            </Button>
          </DrawerClose>
        </DrawerFooter>
      </DrawerContent>
    </Drawer>
  )
}
