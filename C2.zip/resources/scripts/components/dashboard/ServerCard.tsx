"use client"

import React, { useEffect, useRef, useState } from "react"
import type { Server } from "@/api/server/getServer"
import getServerResourceUsage, { type ServerPowerState, type ServerStats } from "@/api/server/getServerResourceUsage"
import { bytesToString, ip, mbToBytes } from "@/lib/formatters"
import tw from "twin.macro"
import CopyOnClick from "@/components/elements/CopyOnClick"
import Spinner from "@/components/elements/Spinner"
import styled, { css } from "styled-components/macro"
import { Installing, Suspended } from "@/lang"
import ServerDetailsSheet from "./ServerDetailsSheet"

// Determines if the current value is in an alarm threshold so we can show it in red rather
// than the more faded default style.
const isAlarmState = (current: number, limit: number): boolean => limit > 0 && current / (limit * 1024 * 1024) >= 0.9

const Card = styled.div<{ $status: ServerPowerState | undefined; $customImage?: string }>`
    ${tw`text-neutral-50 cursor-pointer transition-all duration-300 hover:scale-[1.02]`}
    background-color:var(--secondary);
    border-radius:20px;
    overflow: hidden;
    box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
    
    &:hover {
        box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
    }
`

const CardHeader = styled.div<{ $customImage?: string }>`
    position: relative;
    height: 180px;
    background: ${({ $customImage }) =>
      $customImage ? `url(${$customImage})` : "linear-gradient(135deg, #667eea 0%, #764ba2 100%)"};
    background-size: cover;
    background-position: center;
    padding: 20px;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    
    &::before {
        content: '';
        position: absolute;
        inset: 0;
        background: linear-gradient(to bottom, rgba(0,0,0,0.3) 0%, rgba(0,0,0,0.7) 100%);
    }
    
    & > * {
        position: relative;
        z-index: 1;
    }
`

const ServerTitle = styled.h3`
    ${tw`text-xl font-bold text-white mb-0`}
    text-shadow: 0 2px 4px rgba(0,0,0,0.5);
`

const StatusBadge = styled.div<{ $status: ServerPowerState | undefined }>`
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 6px 12px;
    border-radius: 20px;
    font-size: 0.875rem;
    font-weight: 600;
    backdrop-filter: blur(10px);
    
    ${({ $status }) =>
      !$status || $status === "offline"
        ? css`
                background: rgba(239, 68, 68, 0.2);
                color: #fca5a5;
                border: 1px solid rgba(239, 68, 68, 0.3);
                &::before {
                    content: '●';
                    color: #ef4444;
                }
            `
        : $status === "running"
          ? css`
                background: rgba(34, 197, 94, 0.2);
                color: #86efac;
                border: 1px solid rgba(34, 197, 94, 0.3);
                &::before {
                    content: '●';
                    color: #22c55e;
                }
            `
          : css`
                background: rgba(251, 191, 36, 0.2);
                color: #fde047;
                border: 1px solid rgba(251, 191, 36, 0.3);
                &::before {
                    content: '●';
                    color: #fbbf24;
                }
            `};
`

const CardBody = styled.div`
    padding: 20px;
`

const StatsGrid = styled.div`
    ${tw`grid grid-cols-2 gap-3 mb-4`}
`

const StatItem = styled.div`
    ${tw`flex flex-col`}
    
    & .label {
        ${tw`text-neutral-400 text-xs mb-1`}
    }
    
    & .value {
        ${tw`text-neutral-100 font-semibold text-sm`}
    }
`

const IPAddress = styled.div`
    ${tw`flex items-center gap-2 mb-4 p-3 rounded-lg`}
    background-color: rgba(0, 0, 0, 0.2);
    
    & span {
        ${tw`text-neutral-300 text-sm`}
    }
    
    & b {
        ${tw`text-neutral-100 font-mono text-sm`}
    }
`

type Timer = ReturnType<typeof setInterval>

export default ({ server }: { server: Server; className?: string }) => {
  const interval = useRef<Timer>(null) as React.MutableRefObject<Timer>
  const [isSuspended, setIsSuspended] = useState(server.status === "suspended")
  const [stats, setStats] = useState<ServerStats | null>(null)
  const [isSheetOpen, setIsSheetOpen] = useState(false)

  const getStats = () =>
    getServerResourceUsage(server.uuid)
      .then((data) => setStats(data))
      .catch((error) => console.error(error))

  useEffect(() => {
    setIsSuspended(stats?.isSuspended || server.status === "suspended")
  }, [stats?.isSuspended, server.status])

  useEffect(() => {
    // Don't waste a HTTP request if there is nothing important to show to the user because
    // the server is suspended.
    if (isSuspended) return

    getStats().then(() => {
      interval.current = setInterval(() => getStats(), 30000)
    })

    return () => {
      interval.current && clearInterval(interval.current)
    }
  }, [isSuspended])

  const alarms = { cpu: false, memory: false, disk: false }
  if (stats) {
    alarms.cpu = server.limits.cpu === 0 ? false : stats.cpuUsagePercent >= server.limits.cpu * 0.9
    alarms.memory = isAlarmState(stats.memoryUsageInBytes, server.limits.memory)
    alarms.disk = server.limits.disk === 0 ? false : isAlarmState(stats.diskUsageInBytes, server.limits.disk)
  }

  const diskLimit = server.limits.disk !== 0 ? bytesToString(mbToBytes(server.limits.disk)) : "Unlimited"
  const memoryLimit = server.limits.memory !== 0 ? bytesToString(mbToBytes(server.limits.memory)) : "Unlimited"
  const cpuLimit = server.limits.cpu !== 0 ? server.limits.cpu + " %" : "Unlimited"

  const customImage = (server as any).customImage

  return (
    <>
      <Card $status={stats?.status} $customImage={customImage} onClick={() => setIsSheetOpen(true)}>
        <CardHeader $customImage={customImage}>
          <ServerTitle>{server.name}</ServerTitle>
          <StatusBadge $status={stats?.status}>
            {!stats || stats.status === "offline" ? "Offline" : stats.status === "running" ? "Online" : "Starting"}
          </StatusBadge>
        </CardHeader>

        <CardBody>
          <IPAddress>
            {server.allocations
              .filter((alloc) => alloc.isDefault)
              .map((allocation) => (
                <React.Fragment key={allocation.ip + allocation.port.toString()}>
                  <span>IP:</span>
                  <CopyOnClick text={`${allocation.alias || ip(allocation.ip)}:${allocation.port}`}>
                    <b>
                      {allocation.alias || ip(allocation.ip)}:{allocation.port}
                    </b>
                  </CopyOnClick>
                </React.Fragment>
              ))}
          </IPAddress>

          {!stats || isSuspended ? (
            isSuspended ? (
              <div css={tw`bg-red-800 rounded-lg px-3 py-2 text-xs text-center`}>
                {server.status === "suspended" ? `${Suspended}` : "Connection Error"}
              </div>
            ) : server.isTransferring || server.status ? (
              <div css={tw`bg-neutral-600 rounded-lg px-3 py-2 text-xs text-center`}>
                {server.isTransferring
                  ? "Transferring"
                  : server.status === "installing"
                    ? `${Installing}`
                    : server.status === "restoring_backup"
                      ? "Restoring Backup"
                      : "Unavailable"}
              </div>
            ) : (
              <Spinner size={"small"} />
            )
          ) : (
            <StatsGrid>
              <StatItem>
                <div className="label">CPU</div>
                <div className="value">
                  {stats.cpuUsagePercent.toFixed(2)}% / {cpuLimit}
                </div>
              </StatItem>
              <StatItem>
                <div className="label">Memory</div>
                <div className="value">
                  {bytesToString(stats.memoryUsageInBytes)} / {memoryLimit}
                </div>
              </StatItem>
              <StatItem>
                <div className="label">Disk</div>
                <div className="value">
                  {bytesToString(stats.diskUsageInBytes)} / {diskLimit}
                </div>
              </StatItem>
              <StatItem>
                <div className="label">Network</div>
                <div className="value">
                  ↑ {bytesToString(stats.networkTxInBytes)} ↓ {bytesToString(stats.networkRxInBytes)}
                </div>
              </StatItem>
            </StatsGrid>
          )}
        </CardBody>
      </Card>

      <ServerDetailsSheet server={server} stats={stats} isOpen={isSheetOpen} onClose={() => setIsSheetOpen(false)} />
    </>
  )
}
