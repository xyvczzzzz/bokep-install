"use client"

import { useEffect, useRef, useState } from "react"
import { Link, type RouteComponentProps } from "react-router-dom"
import login from "@/api/auth/login"
import LoginFormContainer from "@/components/auth/LoginFormContainer"
import { useStoreState } from "easy-peasy"
import { Formik, type FormikHelpers } from "formik"
import { object, string } from "yup"
import Field from "@/components/elements/Field"
import tw from "twin.macro"
import Button from "@/components/elements/Button"
import Reaptcha from "reaptcha"
import useFlash from "@/plugins/useFlash"
import * as Lang from "@/lang"
import styled from "styled-components/macro"

interface Values {
  username: string
  password: string
}

const TurnstileContainer = styled.div`
    ${tw`mt-4 flex justify-center`}
    
    .cf-turnstile {
        margin: 0 auto;
    }
`

const StyledField = styled(Field)`
    & input {
        ${tw`bg-neutral-800 border-neutral-700 text-neutral-100 rounded-lg px-4 py-3`}
        transition: all 0.3s ease;
        
        &:focus {
            ${tw`border-purple-500 ring-2 ring-purple-500 ring-opacity-50`}
        }
    }
    
    & label {
        ${tw`text-neutral-300 font-medium mb-2`}
    }
`

const StyledButton = styled(Button)`
    ${tw`w-full py-3 rounded-lg font-semibold text-lg`}
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    transition: all 0.3s ease;
    
    &:hover:not(:disabled) {
        transform: translateY(-2px);
        box-shadow: 0 10px 20px rgba(102, 126, 234, 0.3);
    }
    
    &:disabled {
        opacity: 0.6;
        cursor: not-allowed;
    }
`

const ForgotPasswordLink = styled(Link)`
    ${tw`text-sm tracking-wide no-underline`}
    color: #667eea;
    transition: color 0.3s ease;
    
    &:hover {
        color: #764ba2;
    }
`

const LoginContainer = ({ history }: RouteComponentProps) => {
  const ref = useRef<Reaptcha>(null)
  const [token, setToken] = useState("")
  const [turnstileToken, setTurnstileToken] = useState("")

  const { clearFlashes, clearAndAddHttpError } = useFlash()
  const { enabled: recaptchaEnabled, siteKey } = useStoreState((state) => state.settings.data!.recaptcha)

  useEffect(() => {
    clearFlashes()

    const script = document.createElement("script")
    script.src = "https://challenges.cloudflare.com/turnstile/v0/api.js"
    script.async = true
    script.defer = true
    document.body.appendChild(script)

    return () => {
      document.body.removeChild(script)
    }
  }, [])

  const onSubmit = (values: Values, { setSubmitting }: FormikHelpers<Values>) => {
    clearFlashes()

    // If there is no token in the state yet, request the token and then abort this submit request
    // since it will be re-submitted when the recaptcha data is returned by the component.
    if (recaptchaEnabled && !token) {
      ref.current!.execute().catch((error) => {
        console.error(error)

        setSubmitting(false)
        clearAndAddHttpError({ error })
      })

      return
    }

    login({ ...values, recaptchaData: token })
      .then((response) => {
        if (response.complete) {
          // @ts-expect-error this is valid
          window.location = response.intended || "/"
          return
        }

        history.replace("/auth/login/checkpoint", { token: response.confirmationToken })
      })
      .catch((error) => {
        console.error(error)

        setToken("")
        if (ref.current) ref.current.reset()

        setSubmitting(false)
        clearAndAddHttpError({ error })
      })
  }

  return (
    <Formik
      onSubmit={onSubmit}
      initialValues={{ username: "", password: "" }}
      validationSchema={object().shape({
        username: string().required("A username or email must be provided."),
        password: string().required("Please enter your account password."),
      })}
    >
      {({ isSubmitting, setSubmitting, submitForm }) => (
        <LoginFormContainer title={Lang.LogintoContinue} css={tw`w-full flex`}>
          <StyledField type={"text"} label={Lang.UsernameorEmail} name={"username"} disabled={isSubmitting} />
          <div css={tw`mt-6`}>
            <StyledField type={"password"} label={Lang.Password} name={"password"} disabled={isSubmitting} />
          </div>

          <TurnstileContainer>
            <div
              className="cf-turnstile"
              data-sitekey="0x4AAAAAAB3v2jUdsZs3S8ld"
              data-callback="onTurnstileSuccess"
              data-theme="dark"
            />
          </TurnstileContainer>

          <div css={tw`mt-6`}>
            <StyledButton type={"submit"} size={"xlarge"} isLoading={isSubmitting} disabled={isSubmitting}>
              {Lang.Login}
            </StyledButton>
          </div>
          {recaptchaEnabled && (
            <Reaptcha
              ref={ref}
              size={"invisible"}
              sitekey={siteKey || "_invalid_key"}
              onVerify={(response) => {
                setToken(response)
                submitForm()
              }}
              onExpire={() => {
                setSubmitting(false)
                setToken("")
              }}
            />
          )}
          <div css={tw`mt-6 text-center`}>
            <ForgotPasswordLink to={"/auth/password"}>{Lang.ForgotPassword}</ForgotPasswordLink>
          </div>
        </LoginFormContainer>
      )}
    </Formik>
  )
}

export default LoginContainer
