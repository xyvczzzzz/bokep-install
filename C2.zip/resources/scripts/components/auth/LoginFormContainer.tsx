import type React from "react"
import { forwardRef } from "react"
import { Form } from "formik"
import styled from "styled-components/macro"
import { breakpoint } from "@/theme"
import FlashMessageRender from "@/components/FlashMessageRender"
import tw from "twin.macro"

type Props = React.DetailedHTMLProps<React.FormHTMLAttributes<HTMLFormElement>, HTMLFormElement> & {
  title?: string
}

const Container = styled.div`
    ${breakpoint("sm")`
        ${tw`w-4/5 mx-auto`}
    `};

    ${breakpoint("md")`
        ${tw`p-10`}
    `};

    ${breakpoint("lg")`
        ${tw`w-3/5`}
    `};

    ${breakpoint("xl")`
        ${tw`w-full`}
        max-width: 500px;
    `};

    .box{
        background: rgba(255, 255, 255, 0.05);
        backdrop-filter: blur(20px);
        border: 1px solid rgba(255, 255, 255, 0.1);
        box-shadow: 0 8px 32px 0 rgba(0, 0, 0, 0.37);
    }
`

const Title = styled.h2`
    ${tw`text-4xl text-center font-bold py-6 mb-2`}
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
`

const Subtitle = styled.p`
    ${tw`text-center text-neutral-400 text-sm mb-6`}
`

export default forwardRef<HTMLFormElement, Props>(({ title, ...props }, ref) => (
  <Container>
    {title && (
      <>
        <Title>{title}</Title>
        <Subtitle>Welcome back! Please enter your credentials</Subtitle>
      </>
    )}
    <FlashMessageRender css={tw`mb-2 px-1`} />
    <Form {...props} ref={ref}>
      <div css={tw`md:flex w-full rounded-2xl p-8 mx-1`} className="box">
        <div css={tw`flex-1`}>{props.children}</div>
      </div>
    </Form>
    <p css={tw`text-center text-neutral-500 text-xs mt-6`}>
      &copy; 2015 - {new Date().getFullYear()}&nbsp;
      <span css={tw`text-neutral-400 font-semibold`}>Lanny Yawa</span> &middot; Powered by{" "}
      <a
        rel={"noopener nofollow noreferrer"}
        href={"https://pterodactyl.io"}
        target={"_blank"}
        css={tw`no-underline text-neutral-500 hover:text-neutral-300`}
      >
        Pterodactyl
      </a>
    </p>
  </Container>
))
