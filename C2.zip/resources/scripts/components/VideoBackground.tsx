"use client"

import { useEffect, useState } from "react"
import getTheme from "@/api/getThemeData"

export default () => {
  const [videoUrl, setVideoUrl] = useState<string | null>(null)

  useEffect(() => {
    async function getThemeData() {
      const data = await getTheme()
      // Check if background is a video URL
      if (data.backgroundVideo) {
        setVideoUrl(data.backgroundVideo)
      }
    }
    getThemeData()
  }, [])

  if (!videoUrl) return null

  return (
    <>
      <video className="video-background" autoPlay loop muted playsInline>
        <source src={videoUrl} type="video/mp4" />
        <source src={videoUrl} type="video/webm" />
      </video>
      <div className="video-background-overlay" />
    </>
  )
}
