<?php

namespace Pterodactyl\Exceptions\Service;

use Pterodactyl\Exceptions\DisplayException;

class InvalidFileUploadException extends DisplayException
{
}
